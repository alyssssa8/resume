
#include <string>
#include <iostream>
#include <fstream>
#include <unordered_set>
#include "RBTreeMap.h"
// Any other classes you make

const char* ws = " \t\n\r\f\v";
const int MAX_VALUE = 256;

class Game {
public:
    bool PromptYesNoMessage(std::string msg) {
        while (true) {
            std::cout << msg << "(y/n) ";
            std::string response;
            std::cin >> response;
            std::cin.clear();
            std::cin.ignore(MAX_VALUE, '\n');
            if (response == "y")
                return true;
            if (response == "n")
                return false;
            std::cout << "Please enter y or n..." << std::endl;
        }
    }

    int PromptGuesses()
    {
        unsigned int len = 0;
        while (true) {
            std::cout << "Please enter how many guesses: ";
            std::cin >> len;
            std::cin.clear();
            std::cin.ignore(MAX_VALUE, '\n');
            if (len > 0)
                return len;
            else
                std::cout << "Invalid number of guesses." << std::endl;
        }
    }

    int PromptWordLength()
    {
        unsigned int len = 0;
        while (true) {
            std::cout << "Please enter how long is the word: ";
            std::cin >> len;
            std::cin.clear();
            std::cin.ignore(MAX_VALUE, '\n');
            if (len >= min_word_length && len <= max_word_length)
                return len;
            else
                std::cout << "Invalid length of the word." << std::endl;
        }
        return len;
    }

    std::string PromptGuess()
    {
        std::string guess = "";

        while (true) {
            std::cout << "Please enter a guess:";
            std::cin >> guess;
            std::cin.clear();
            std::cin.ignore(MAX_VALUE, '\n');
            if (guess.size() == 1 &&
                ((guess[0] >= 'A' && guess[0] <= 'Z') || (guess[0] >= 'a' && guess[0] <= 'z')) &&
                guessed_letters.find(guess[0]) == std::string::npos) {

                guessed_letters += guess;
                return guess;
            }
            else
                std::cout << "Invalid guess." << std::endl;
        }        

        return guess;
    }

    bool isWin(std::string guessedProgress)
    {
        return guessedProgress.find("*") == std::string::npos;
    }

    void PlayEvilHangman(std::string file)
    {
        word_length = PromptWordLength();
        guesses_num = PromptGuesses();

        // initialize word list based on word length
        word_list.clear();
        for (std::string word : whole_dictionary) {
            if (word.size() == word_length) {
                word_list.insert(word);
            }
        }

        // initialize guessed progress to "******" based on word length
        // initialize current guess number
        guessed_progress = std::string(word_length, '*');
        guessed_letters = "";
        current_guess_num = 0;

        bool user_win = false;

        while (current_guess_num < guesses_num) {
            // make a guess
            std::string new_guess = PromptGuess();
            current_guess_num += 1;

            // construct map based on remaining words, progress, and new guess
            for (std::string word : word_list) {
                map.insert(word, guessed_progress, new_guess);
            }

            // start to cheat, find the largest family and the key
            std::string largest_family_key = map.getLargestFamilyKey();
            word_list = map.getInfo(largest_family_key);

            if (largest_family_key == std::string(word_length, '*')) {
                // if the guess didn't hit any letter, which means a key "******", then don't change the guessed progress
                std::cout << "Wrong guess, the guess was not in the word." << std::endl;
            }
            else {
                // if the guess hit any letter, update the guessed progress
                std::cout << "Correct guess." << std::endl;
                guessed_progress = largest_family_key;

                if (isWin(guessed_progress)) {
                    // if there is no "*", user won
                    user_win = true;
                    break;
                }
            }

            // output the cheating strategy in debug mode
            if (debug == true) {
                std::cout << "=================================" << std::endl;
                std::cout << "Debug cheat info:" << std::endl;
                std::cout << "Largest word family word:" << std::endl;
                for (std::string word : word_list) {
                    std::cout << "    " << word << std::endl;
                }
                std::cout << "Largest word family count: " << word_list.size() << std::endl;
                std::cout << "Largest word family key pattern: " << guessed_progress << std::endl;
                std::cout << "=================================" << std::endl;
            }

            std::cout << "Total guess number allowed: " << guesses_num << ". Now you have used: " << current_guess_num << std::endl;
            std::cout << "Now What you have is: " << guessed_progress << std::endl;
            std::cout << "The letters you have guessed: " << guessed_letters << std::endl << std::endl;
            map.reset();
        }

        if (user_win == true) {
            std::cout << "Congratulations! You Win! The word is: " << guessed_progress << std::endl;
        }
        else {
            std::cout << "Sorry, you lose." << std::endl;
        }
        return;
    }

    void LoadFile() {
        /*
        std::cout << "Enter dictionary file: ";
        std::cin >> file_name;
        */

        std::ifstream file;
        file.open(file_name);
        if (file.is_open()) {
            std::string line;
            while (std::getline(file, line)) {
                line = trim(line);
                if (line != "") {
                    whole_dictionary.insert(line);
                    if (line.size() > max_word_length) {
                        max_word_length = line.size();
                    }
                    if (line.size() < min_word_length) {
                        min_word_length = line.size();
                    }
                }
            }
        }
        else {
            std::cout << "the file does not exist." << std::endl;
            exit(-1);
        }
    }

    void StartGame() {
        while (true) {
            debug = PromptYesNoMessage("Turn debugging on?");
            PlayEvilHangman(file_name);
            if (!PromptYesNoMessage("Would you like to play again ?"))
                break;
        }
    }

private:
    bool debug;
    std::unordered_set<std::string> whole_dictionary;
    std::unordered_set<std::string> word_list;
    std::string file_name = "dictionary.txt";
    unsigned int guesses_num = 0;
    unsigned int current_guess_num = 0;
    unsigned int word_length = 0;
    unsigned int max_word_length = 0;
    unsigned int min_word_length = MAX_VALUE;
    std::string guessed_letters = "";
    std::string guessed_progress = "";
    RBTreeMap<std::string, std::unordered_set<std::string>> map;

    // trim from end of string (right)
    inline std::string& rtrim(std::string& s, const char* t = ws)
    {
        s.erase(s.find_last_not_of(t) + 1);
        return s;
    }

    // trim from beginning of string (left)
    inline std::string& ltrim(std::string& s, const char* t = ws)
    {
        s.erase(0, s.find_first_not_of(t));
        return s;
    }

    // trim from both ends of string (right then left)
    inline std::string& trim(std::string& s, const char* t = ws)
    {
        return ltrim(rtrim(s, t), t);
    }

};

int main()
{
    Game game;
    game.LoadFile();
    game.StartGame();
    return 0;
}


