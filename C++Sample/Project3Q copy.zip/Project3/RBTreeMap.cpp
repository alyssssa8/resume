#include "RBTreeMap.h"
#include <iostream>
#include <unordered_set>

template<typename K, typename T>
RBTreeMap<K, T>::RBTreeMap() {
    reset();
}

template<typename K, typename T>
RBTreeMap<K, T>::~RBTreeMap()
{
}

template<typename K, typename T>
void RBTreeMap<K, T>::add(K newKey, T newInfo)
{
    root[newKey] = newInfo;
}

template<typename K, typename T>
void RBTreeMap<K, T>::remove(K newKey)
{
    root.erase(newKey);
}

template<typename K, typename T>
void RBTreeMap<K, T>::insert(std::string word, std::string guessed_progress, std::string new_guess)
{
    // based on guessed_progress that already fixed. and the new_guess
    // we can decide the family of current word
    std::string key = guessed_progress;
    bool match = false;
    for (unsigned int i = 0; i < word.size(); i++) {
        if (key[i] == '*') {
            if (word[i] == new_guess[0]) {
                // change a '*' in the key to the matched guess value
                // for example:
                // if word is "book", key is "****" and currenly i is 0 and new_guess is "b"
                // then change the key to "b***"
                key[i] = new_guess[0];
                match = true;
            }
            else {
                continue;
            }
        }
        else {
            if (word[i] != key[i]) {
                break;
            }
            else {
                continue;
            }
        }
    }

    // assign the special key to not belong any family "******"
    if (match == false) {
        key = std::string(word.size(), '*');
    }

    // now you get the key, search the tree by key and put the word to the tree
    root[key].insert(word);
    if (root[key].size() > largest_family_size) {
        largest_family_size = root[key].size();
        largest_family_key = key;
    }
}

template<typename K, typename T>
void RBTreeMap<K, T>::reset()
{
    root.clear();
    largest_family_size = 0;
}

template<typename K, typename T>
T RBTreeMap<K, T>::getInfo(K key)
{
    return (root.find(key))->second;
}

template<typename K, typename T>
K RBTreeMap<K, T>::getLargestFamilyKey()
{
    return largest_family_key;
}

template class RBTreeMap<std::string, std::unordered_set<std::string>>;


