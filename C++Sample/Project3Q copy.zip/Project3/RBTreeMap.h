#pragma once
#include <map>
#include <string>

template<typename K, typename T>
struct Node {
    K key;
    T info;
    Node<K, T>* left;
    Node<K, T>* right;
    Node<K, T>* parent;
    bool black;
};

template<typename K, typename T>
class RBTreeMap
{
public:
    RBTreeMap();
    ~RBTreeMap();

    // Adds newInfo to the tree using newKey as a key
    void add(K newKey, T newInfo);

    // Removes node that contains newKey
    void remove(K newKey);

    // Reset tree
    void reset();

    // get largest family key
    K getLargestFamilyKey();

    // Insert new word to the tree
    void insert(std::string word, std::string guessed_progress, std::string new_guess);

    // Returns info associated with key.
    T getInfo(K key);
    // Returns a default T() otherwise.
private:
    //Node<K, T>* root;
    std::map<K, T> root;
    int length;
    unsigned int largest_family_size;
    K largest_family_key;
    // Add helpers if required
};